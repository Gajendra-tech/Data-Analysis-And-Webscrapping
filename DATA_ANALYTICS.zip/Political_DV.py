#Political party Analysis - Data Science Application
import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import *

party_data = {
    'Party': ['NDA', 'JDS', 'UPA', 'DMK'],
    'Ideology': ['Integral Humanism', 'Center-right', 'Left-wing', 'Center-wing'],
    'Leader': ['Narendra Modi', 'Deve Gouda', 'Rahul Gandhi', 'MK Stalin'],
    'Vote_Share_2019': [45, 8, 19, 20],  # Percentage of vote share in 2019 elections
    'Campaign_Budget': [1000000, 100000, 1200000, 600000], 
    'inflation':[6.1, 1.1, 9.5,2.1],
     # Add more factors for analysis as needed
}

# Create a DataFrame from the data
party_df = pd.DataFrame(party_data)

#Window Creation 
window=tk.Tk()
window.title("Political Data Display")
window.geometry("400x800+400+0")

# Basic analysis
#print("Basic Analysis of Political Parties:")
#print()

l1=tk.Label(window,text='Basic analysis of GDP Data',font='arial 18 bold',bg='skyblue')
l1.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

# 1. Party Ideology
#print("1. Party Ideology:")
#print(party_df[['Party', 'Ideology']])
#print()

PL=tk.Label(window,text='1. Party Ideology',font='sans 14 bold',bg='lightgreen')
PL.grid(row=1,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

LPL=(party_df[['Party','Ideology']])
RPL_L=tk.Label(window,text=LPL,font='sans 12 bold')
RPL_L.grid(row=2,column=0)

# 2. Leadership
#print("2. Leadership:")
#print(party_df[['Party', 'Leader']])
#print()

P2=tk.Label(window,text='2. Party Leadership',font='sans 14 bold',bg='lightgreen')
P2.grid(row=3,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

P2=(party_df[['Party','Leader']])
P2_L=tk.Label(window,text=P2,font='sans 12 bold')
P2_L.grid(row=4,column=0)

# 3. Electoral Performance
#print("3. Electoral Performance:")
#print(party_df[['Party', 'Vote_Share_2019']])
#print()

P3=tk.Label(window,text='3. Electrol Performance',font='sans 14 bold',bg='lightgreen')
P3.grid(row=5,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

P3=(party_df[['Party','Vote_Share_2019']])
P3_L=tk.Label(window,text=P3,font='sans 12 bold')
P3_L.grid(row=6,column=0)

# 4. Campaign Budget Analysis
#print("4. Campaign Budget Analysis:")
# Calculate average campaign budget
average_budget = party_df['Campaign_Budget'].mean()
#print("Average Campaign Budget: ${:,.2f}".format(average_budget))

P4=tk.Label(window,text='4.Average Campaign Budget Analysis',font='sans 14 bold',bg='lightgreen')
P4.grid(row=7,column=0,columnspan=2,padx=10,pady=10,sticky='nswe')

P4=tk.Label(window,text='4. Average Campaign Budget',font='sans 14 bold',bg='lightgreen')
P4.grid(row=8,column=0,padx=10,pady=10)
P4=(average_budget)
P4_L=tk.Label(window,text=P4,font='12')
P4_L.grid(row=8,column=1,columnspan=2,padx=10,pady=10,sticky='nswe')

avg_inflation=party_df['inflation'].mean()
#print("Average Inflation: {}".format(avg_inflation))

Avg_I=tk.Label(window,text='4.Average Inflation',font='sans 12 bold',bg='lightgreen')
Avg_I.grid(row=9,column=0,padx=10,pady=10)
P5=(avg_inflation)
P5_L=tk.Label(window,text=P5,font='12')
P5_L.grid(row=9,column=1,columnspan=2,padx=10,pady=10,sticky='nswe')

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=10,columnspan=4,padx=10,pady=10)
# Identify parties with above-average campaign budgets
#above_average_budget = party_df[party_df['Campaign_Budget'] > average_budget]
#print("Parties with Above Average Campaign Budget:")
#print(above_average_budget[['Party', 'Campaign_Budget']])
#print()

# Plotting Electoral Performance
plt.figure(figsize=(10, 5))
plt.bar(party_df['Party'], party_df['Vote_Share_2019'], color=['orange', 'green', 'blue', 'red'])
plt.xlabel('Party')
plt.ylabel('Vote Share (%)')
plt.title('Electoral Performance in 2019')
plt.ylim(0, 40)  # Setting y-axis limit for better visualization
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

# Plotting Campaign Budgets
plt.figure(figsize=(10, 5))
plt.bar(party_df['Party'], party_df['Campaign_Budget'], color='lightgreen')
plt.xlabel('Party')
plt.ylabel('Campaign Budget ($)')
plt.title('Campaign Budgets')
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()
