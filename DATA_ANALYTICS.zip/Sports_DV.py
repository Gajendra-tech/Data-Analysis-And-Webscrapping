#Data Analysis On Sports (Soccer &Cricket)-python
import pandas as pd
import matplotlib.pyplot as plt 
import tkinter as tk
from tkinter import *

Sports_data={
      'Sports':['Cricket','Soccer'],
      'Playing_Nations':[85,204],
      'Top_Continent':['Asia','America'],
      'Viewership':[2.5,3.5],
      'Playing_time':[10,1.3],
      'Popular_league':['ICC World Cup','WIFA World Cup'],
      'Prize_money':[10,42],
      'Revenue':[9.5,14],
      'Market_Size':[2.9,3.3]
}

#Create DataFrame from data 
sports_df=pd.DataFrame(Sports_data)

#Window Creation 
window=tk.Tk()
window.title("Sports Data Display")
window.geometry("650x800+400+0")

#Basic Analysis of Sports
#print('Basic Analysis of Sports data')
#print()

l1=tk.Label(window,text='Basic analysis  Sports Data',font='arial 18 bold',bg='skyblue')
l1.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#1.Popular League
#print('1. Popular_Leagues:')
#print(sports_df[['Sports','Popular_league']])
#print()

S1=tk.Label(window,text='1. Popular Leagues',font='sans 14 bold',bg='lightgreen')
S1.grid(row=1,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

S1=(sports_df[['Sports','Popular_league']])
S1_L=tk.Label(window,text=S1,font='sans 12 bold')
S1_L.grid(row=2,column=0)

#2.Top Continent
#print('2. Top Continent by Popularity:')
#print(sports_df[['Sports','Top_Continent']])
#print()

S2=tk.Label(window,text='2. Top Continent by Popularity',font='sans 14 bold',bg='lightgreen')
S2.grid(row=3,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

S2=(sports_df[['Sports','Top_Continent']])
S2_L=tk.Label(window,text=S2,font='sans 12 bold')
S2_L.grid(row=4,column=0)

#3.Viewership
#print('3. Viewership:')
#print(sports_df[['Sports','Viewership']])
#print()

S3=tk.Label(window,text='3. Viewership',font='sans 14 bold',bg='lightgreen')
S3.grid(row=5,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

S3=(sports_df[['Sports','Viewership']])
S3_L=tk.Label(window,text=S3,font='sans 12 bold')
S3_L.grid(row=6,column=0)

#4.Playing Time
#print('4. Sports Playing_time:')
#print(sports_df[['Sports','Playing_time']])
#print()

S4=tk.Label(window,text='4. Playing Time',font='sans 14 bold',bg='lightgreen')
S4.grid(row=7,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

S4=(sports_df[['Sports','Playing_time']])
S4_L=tk.Label(window,text=S4,font='sans 12 bold')
S4_L.grid(row=8,column=0)

#5.Playing Nation
#print('5.Total Playing Nations:')
#print(sports_df[['Sports','Playing_Nations']])
#print()

S5=tk.Label(window,text='5. Total Playing Nations',font='sans 14 bold',bg='lightgreen')
S5.grid(row=1,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

S5=(sports_df[['Sports','Playing_Nations']])
S5_L=tk.Label(window,text=S5,font='sans 12 bold')
S5_L.grid(row=2,column=4)
      
#6.Prize money
#print('6. Prize money In US Dolars:')
#print(sports_df[['Sports','Prize_money']])
#print()

S6=tk.Label(window,text='6. Prize money In US Dolars',font='sans 14 bold',bg='lightgreen')
S6.grid(row=3,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

S6=(sports_df[['Sports','Prize_money']])
S6_L=tk.Label(window,text=S6,font='sans 12 bold')
S6_L.grid(row=4,column=4)

#7.Revenue Generation
#print('7. Revenue Revenue in Billion Dolars:')
#print(sports_df[['Sports','Revenue']])
#print()

S7=tk.Label(window,text='7. Revenue In Billion Dolars',font='sans 14 bold',bg='lightgreen')
S7.grid(row=5,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

S7=(sports_df[['Sports','Revenue']])
S7_L=tk.Label(window,text=S7,font='sans 12 bold')
S7_L.grid(row=6,column=4)

#8.Market Size
#print('8. Market Size in Million and Billions $')
#print(sports_df[['Sports','Market_Size']])
#print()

S8=tk.Label(window,text='8. Market Size in Million and Billion $',font='sans 14 bold',bg='lightgreen')
S8.grid(row=7,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

S8=(sports_df[['Sports','Market_Size']])
S8_L=tk.Label(window,text=S8,font='sans 12 bold')
S8_L.grid(row=8,column=4)

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=11,columnspan=5,padx=10,pady=10)

#Plotting no of Playing countries
plt.figure(figsize=(10,5))
plt.bar(sports_df['Sports'],sports_df['Playing_Nations'],color=['orange','green'])
plt.xlabel('Sports')
plt.ylabel('Playing_Nations')
plt.title('Highest sports playing countries')
plt.ylim(0,250) #Setting y-axis limit  for better visualization
plt.yticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

#Plotting total winners prize money
plt.figure(figsize=(10,5))
plt.bar(sports_df['Sports'],sports_df['Prize_money'],color=['skyblue','lightgreen'])
plt.xlabel('Sports')
plt.ylabel('Prize_money')
plt.title('Winners Prize money in US Dolars')
plt.ylim(0.50) #Setting y-axis limit  for better visualization
plt.yticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()





















