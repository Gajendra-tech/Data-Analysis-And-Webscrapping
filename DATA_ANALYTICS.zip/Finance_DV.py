#Data Analysis On Finance -python
import pandas as pd
import matplotlib.pyplot as plt 
import tkinter as tk
from tkinter import *

Finance_Data={
      'Finance':['GDP_Japan','GDP_India'],
      'GDP_2024':[4.2,4.1],#In Trillion
      'GDP_2000':[4.7,493],#In Trillion & Billion
      'GDP_Growth_2024':[0.5,6.2],#In Percentage
      'GDP_Growth_2000':[2.7,3.8],#In Percentage
      'Exported_Value_2024':[680,300],#In Billion
      'Exported_Value_2000':[519,60],#In Billion
      'FDI_2024':[1.6,610],#In Trillion & Billion
      'FDI_2000':[225,220],#In Billion
      'Inflation_2024':[3.4,5],#In Percentage
      'Inflation_2000':[0.1,4],#In percentage
}

#Create DataFrame from data 
Finance_df=pd.DataFrame(Finance_Data)

#Window Creation 
window=tk.Tk()
window.title("Political Data Display")
window.geometry("750x800+350+0")

#Basic Analysis of Finance
#print('Basic Analysis of Finance Data')
#print()
l1=tk.Label(window,text='Basic analysis Finance Data',font='arial 18 bold',bg='skyblue')
l1.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#1.Gross Demenstic Products
#print('1.Gross Demenstic Products GDP_2024:')
#print(Finance_df[['Finance','GDP_2024']])
#print()

F1=tk.Label(window,text='1. Gross Demenstic Products (GDP_2024)',font='sans 14 bold',bg='lightgreen')
F1.grid(row=1,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

F1=(Finance_df[['Finance','GDP_2024']])
F1_L=tk.Label(window,text=F1,font='sans 12 bold')
F1_L.grid(row=2,column=0)

#2.Gross Demenstic Products
#print('2.Gross Demenstic Products GDP_2000:')
#print(Finance_df[['Finance','GDP_2000']])
#print()

F2=tk.Label(window,text='2. Gross Demenstic Products GDP_2000)',font='sans 14 bold',bg='lightgreen')
F2.grid(row=3,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

F2=(Finance_df[['Finance','GDP_2000']])
F2_L=tk.Label(window,text=F2,font='sans 12 bold')
F2_L.grid(row=4,column=0)

#3.GDP 
#print('3.GDP Growth 2024 :')
#print(Finance_df[['Finance','GDP_Growth_2024']])
#print()

F3=tk.Label(window,text='3.GDP Growth 2024',font='sans 14 bold',bg='lightgreen')
F3.grid(row=5,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

F3=(Finance_df[['Finance','GDP_Growth_2024']])
F3_L=tk.Label(window,text=F3,font='sans 12 bold')
F3_L.grid(row=6,column=0)

#4.GDP In 2000 
#print('4.GDP Growth 2000:')
#print(Finance_df[['Finance','GDP_Growth_2000']])
#print()

F4=tk.Label(window,text='4. GDP Growth  2000 ',font='sans 14 bold',bg='lightgreen')
F4.grid(row=7,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

F4=(Finance_df[['Finance','GDP_Growth_2024']])
F4_L=tk.Label(window,text=F4,font='sans 12 bold')
F4_L.grid(row=8,column=0)

#5.GDP Exported Value 2024
#print('5.Exported Value:')
#print(Finance_df[['Finance','Exported_Value_2024']])
#print()

F5=tk.Label(window,text='5. Exported Value',font='sans 14 bold',bg='lightgreen')
F5.grid(row=9,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

F5=(Finance_df[['Finance','Exported_Value_2024']])
F5_L=tk.Label(window,text=F5,font='sans 12 bold')
F5_L.grid(row=10,column=0)

#6.GDP Exported Value 2000
#print('6.Exported Value :')
#print(Finance_df[['Finance','Exported_Value_2000']])
#print()

F6=tk.Label(window,text='6. Exported Value 2000',font='sans 14 bold',bg='lightgreen')
F6.grid(row=1,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

F6=(Finance_df[['Finance','Exported_Value_2000']])
F6_L=tk.Label(window,text=F6,font='sans 12 bold')
F6_L.grid(row=2,column=4)

#7.FDI(Foreign Direct Investment)
#print('7.Foreign Direct Investment(FDI):')
#print(Finance_df[['Finance','FDI_2024']])
#print()

F7=tk.Label(window,text='7. Foreign Direct Investment',font='sans 14 bold',bg='lightgreen')
F7.grid(row=3,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

F7=(Finance_df[['Finance','FDI_2024']])
F7_L=tk.Label(window,text=F7,font='sans 12 bold')
F7_L.grid(row=4,column=4)

#8.FDI(Foreign Direct Investment)
#print('8.Foreign Direct Investment(FDI):')
#print(Finance_df[['Finance','FDI_2000']])
#print()

F8=tk.Label(window,text='8. Foreign Direct Investment 2000',font='sans 14 bold',bg='lightgreen')
F8.grid(row=5,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

F8=(Finance_df[['Finance','FDI_2000']])
F8_L=tk.Label(window,text=F8,font='sans 12 bold')
F8_L.grid(row=6,column=4)

#9.Inflation
#print('9.Inflation:')
#print(Finance_df[['Finance','Inflation_2024']])
#print()

F9=tk.Label(window,text='9. Inflation 2024',font='sans 14 bold',bg='lightgreen')
F9.grid(row=7,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

F9=(Finance_df[['Finance','Inflation_2024']])
F9_L=tk.Label(window,text=F9,font='sans 12 bold')
F9_L.grid(row=8,column=4)

#10.Inflation 
#print('10.Inflation:')
#print(Finance_df[['Finance','Inflation_2000']])#
#print()

F10=tk.Label(window,text='10. Inflation 2000',font='sans 14 bold',bg='lightgreen')
F10.grid(row=9,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

F10=(Finance_df[['Finance','Inflation_2000']])
F10_L=tk.Label(window,text=F10,font='sans 12 bold')
F10_L.grid(row=10,column=4)

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=11,columnspan=5,padx=10,pady=10)

#Plotting country GDP 2024 
plt.figure(figsize=(10,5))
plt.bar(Finance_df['Finance'],Finance_df['GDP_2024'],color=['green','orange'])
plt.xlabel('Finance')
plt.ylabel('GDP_2024')
plt.title('Total GDP in USD Trillion 2024')
plt.ylim(0,5) #Setting y-axis limit  for better visualization
plt.yticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

#Plotting country FDI 2024 
plt.figure(figsize=(10,5))
plt.bar(Finance_df['Finance'],Finance_df['Exported_Value_2024'],color=['skyblue','lightgreen'])
plt.xlabel('Finance')
plt.ylabel('Exported_Value_2024')
plt.title('Total Export in USD Billion 2024')
plt.ylim(0,700) #Setting y-axis limit  for better visualization
plt.yticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()






