#Data Analysis On Technology -python
import pandas as pd
import matplotlib.pyplot as plt 
import tkinter as tk
from tkinter import *

Technology_data={
      'Technology':['Apple','Microsoft'],
      'Founded':[1976,1975],
      'Founder':['SteveJobs','Billgates'],
      'Headquaters':['California','Washington'],
      'Products':['Iphone','Softwere_Development'],
      'Services':['App_store','Microsoft365'],
      'Revenue':[394,211],
      'Number_of_Employees':[161000,221000],
      'Assets':[352,411],
      'Market_Cap':[2.6,3],
}

#Create DataFrame from data 
Technology_df=pd.DataFrame(Technology_data)

#Window Creation 
window=tk.Tk()
window.title("Technology Data Display")
window.geometry("650x800+400+0")

#Basic Analysis of Sports
#print('Basic Analysis of Technology data')
#print()

l1=tk.Label(window,text='Basic analysis Technology Data',font='arial 18 bold',bg='skyblue')
l1.grid(row=0,column=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#1.Founded in 
#print('1.Founded In:')
#print(Technology_df[['Technology','Founded']])
#print()

T1=tk.Label(window,text='1. Founded In',font='sans 14 bold',bg='lightgreen')
T1.grid(row=1,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

T1=(Technology_df[['Technology','Founded']])
T1_L=tk.Label(window,text=T1,font='sans 12 bold')
T1_L.grid(row=2,column=0)

#2.Founders 
#print('2.Founders:')
#print(Technology_df[['Technology','Founder']])
#print()

T2=tk.Label(window,text='2. Founder',font='sans 14 bold',bg='lightgreen')
T2.grid(row=3,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

T2=(Technology_df[['Technology','Founder']])
T2_L=tk.Label(window,text=T2,font='sans 12 bold')
T2_L.grid(row=4,column=0)

#3.Headquaters
#print('3.Headquaters:')
#print(Technology_df[['Technology','Headquaters']])
#print()

T3=tk.Label(window,text='3. Headquaters',font='sans 14 bold',bg='lightgreen')
T3.grid(row=5,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

T3=(Technology_df[['Technology','Headquaters']])
T3_L=tk.Label(window,text=T3,font='sans 12 bold')
T3_L.grid(row=6,column=0)

#4.Produts
#print('4.Products:')
#print(Technology_df[['Technology','Products']])
#print()

T4=tk.Label(window,text='4. Products',font='sans 14 bold',bg='lightgreen')
T4.grid(row=7,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)

T4=(Technology_df[['Technology','Products']])
T4_L=tk.Label(window,text=T4,font='sans 12 bold')
T4_L.grid(row=8,column=0)

#5.Service
#print('5.Services:')
#print(Technology_df[['Technology','Services']])
#print()

T5=tk.Label(window,text='5. Services',font='sans 14 bold',bg='lightgreen')
T5.grid(row=1,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

T5=(Technology_df[['Technology','Services']])
T5_L=tk.Label(window,text=T5,font='sans 12 bold')
T5_L.grid(row=2,column=4)

#6.Revenue Generation 
#print('6.Revenue in US Dolars Billion:')
#print(Technology_df[['Technology','Revenue']])
#print()

T6=tk.Label(window,text='6. Revenue In US Dolars Billion',font='sans 14 bold',bg='lightgreen')
T6.grid(row=3,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

T6=(Technology_df[['Technology','Revenue']])
T6_L=tk.Label(window,text=T6,font='sans 12 bold')
T6_L.grid(row=4,column=4)

#7.Numbers of Employees
#print('7.Number_of_Employees:')
#print(Technology_df[['Technology','Number_of_Employees']])
#print()

T7=tk.Label(window,text='7. Numbers Of Employees',font='sans 14 bold',bg='lightgreen')
T7.grid(row=5,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

T7=(Technology_df[['Technology','Number_of_Employees']])
T7_L=tk.Label(window,text=T7,font='sans 12 bold')
T7_L.grid(row=6,column=4)

#8.Assets
#print('8.Total_Assets in US Dolars:')
#print(Technology_df[['Technology','Assets']])
#print()

T8=tk.Label(window,text='8. Total In US Dolars',font='sans 14 bold',bg='lightgreen')
T8.grid(row=7,column=4,columnspan=4,sticky='nsew',padx=10,pady=10)

T8=(Technology_df[['Technology','Assets']])
T8_L=tk.Label(window,text=T8,font='sans 12 bold')
T8_L.grid(row=8,column=4)

#9.Market Value/Market Capitilization
#print('9.Market_Cap in US Dolars in Billion :')
#print(Technology_df[['Technology','Market_Cap']])
#print()

T9=tk.Label(window,text='9. Market_Cap In US Dolars I Billion',font='sans 14 bold',bg='lightgreen')
T9.grid(row=9,column=4,sticky='nsew',padx=10,pady=10)

T9=(Technology_df[['Technology','Market_Cap']])
T9_L=tk.Label(window,text=T9,font='sans 12 bold')
T9_L.grid(row=10,column=4)

bt=tk.Button(window,width=10,height=2,text='Exit',font='sans 12 bold',bg='black',fg='white',command=window.destroy)
bt.grid(row=10,columnspan=4,padx=10,pady=10)

#Plotting Market Capitalization 
plt.figure(figsize=(10,5))
plt.bar(Technology_df['Technology'],Technology_df['Market_Cap'],color=['orange','green'])
plt.xlabel('Technology')
plt.ylabel('Market_Cap')
plt.title('Total Market Capitilization USD Trillion')
plt.ylim(0,10) #Setting y-axis limit  for better visualization
plt.yticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()

#Plotting Revenue Generation 
plt.figure(figsize=(10,5))
plt.bar(Technology_df['Technology'],Technology_df['Revenue'],color=['skyblue','lightgreen'])
plt.xlabel('Technology')
plt.ylabel('Revenue')
plt.title('Total Revenue Generation USD Million')
plt.ylim(0,400) #Setting y-axis limit  for better visualization
plt.yticks(rotation=45)
plt.grid(axis='y',linestyle='--',alpha=0.7)
plt.tight_layout()
plt.show()






